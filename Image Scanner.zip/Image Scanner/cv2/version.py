opencv_version = "4.9.0.80"
contrib = True
headless = False
rolling = False
ci_build = True